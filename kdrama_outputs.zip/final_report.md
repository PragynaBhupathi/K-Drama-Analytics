# K-Drama Analytics: Final Report

## 1. Project overview
This project cleans a Kaggle K-Drama dataset and explores it with statistics, visualisation, clustering and a rating-prediction experiment. Every number below was computed from the data.

## 2. Dataset description
- File: /root/.cache/kagglehub/datasets/ahbab911/top-250-korean-dramas-kdrama-dataset/versions/1/kdrama.csv
- Original size: 250 rows x 17 columns; after cleaning: 250 dramas
- Columns recognised: content_rating = Content Rating, title = Name, year = Year of release, date = Aired Date, rating = Rating, episodes = Number of Episodes, network = Original Network, genre = Genre, cast = Cast, director = Director, rank = Rank, duration = Duration
- Not available in this dataset: popularity

## 3. Data cleaning summary
- Text normalisation: 14 text columns tidied; 0 placeholder cells set to missing
- Duplicate removal: 0 identical rows + 0 same-title/same-year rows removed
- Rows without a title: 0 rows removed
- Data-type correction: 6 conversions applied
- Category harmonisation (Content Rating): 0 variant spellings merged
- Multi-value split (Genre): 0 spelling variants merged -> 29 distinct items
- Multi-value split (Original Network): 0 spelling variants merged -> 23 distinct items
- Multi-value split (Cast): 0 spelling variants merged -> 829 distinct items
- Multi-value split (Director): 0 spelling variants merged -> 183 distinct items
- Validation and outliers: 0 impossible values set to missing; outliers flagged and kept
- Missing-value policy: no imputation for analysis; each analysis uses available rows only

## 4. Key findings
1. **Dataset scale**: The cleaned dataset holds 250 dramas spanning 2003 to 2022.
2. **Most productive year**: 2021 had the most dramas (39), which is 15.6% of dramas with a known year.
3. **Industry growth**: The later half of the period (2013 to 2022) has 234 dramas versus 16 in the earlier half (1362% change). Biggest single-year jump: 2017.
4. **Dominant genres**: The three most common genres are Romance (136), Drama (129), Mystery (90). 'Romance' appears in 54% of dramas.
5. **Best and lowest rated genres**: Among genres with at least 5 dramas, 'Friendship' has the highest average rating (8.79) and 'Business' the lowest (8.49).
6. **Typical rating**: The average rating is 8.53 (median 8.5); the middle 50% of dramas score between 8.3 and 8.7.
7. **Highest-rated drama**: 'Move to Heaven' has the top rating (9.2). The top 10 range from 9.0 to 9.2.
8. **Network concentration**: 'tvN' leads with 77 dramas (31% of the dataset); the top 3 networks hold 55% of all network credits.

## 5. Important visualizations
Top-10 rated dramas, common genres, production by year, rating and episode distributions, network comparison, genre vs rating, correlation heatmap, rating vs episodes, actors and directors, cluster map and the interactive dashboard.

## 6. Statistical observations
- Rating: mean 8.53, median 8.5, std 0.22, range 8.3 to 9.2
- Number of Episodes: mean 19.06, median 16.0, std 13.25, range 1.0 to 133.0
- Duration: mean 62.41, median 65.0, std 14.96, range 15.0 to 100.0
- Episodes vs rating: Pearson -0.1, Spearman -0.06

## 7. Business insights
- **Strongest rated network**: Among networks with at least 5 rated dramas, 'Netflix' has the best average rating (8.66), with 52% of its dramas in the overall top 25%.
- **Typical series length**: The median drama has 16 episodes; 70% have 16 episodes or fewer, while the longest runs 133 episodes.
- **Length vs quality**: Episode count and rating have a weak negative relationship (Spearman -0.06). Length alone does not explain quality.
- **Rating trend over time**: Average ratings change by 0.104 points per decade (statistically significant).
- **Most frequent actor**: 'Lee Joon Hyuk' appears in 8 dramas (average rating 8.61).
- **Most prolific director**: 'Kim Won Suk' directed 6 dramas in this dataset.
- **Profile of top-25% rated dramas**: Compared with the rest (rating >= 8.7): median episodes 16 vs 16; median release year 2020 vs 2019; median episode length 70 vs 65 min.
- **Data completeness**: The most incomplete column is 'Content Rating' with 5 missing values. Findings that use it rely only on the rows where it exists.
- **Prediction experiment**: Random Forest reached R2 0.13 and MAE 0.18 on unseen dramas.

## 8. Limitations
- This is a Top-250 list, so every drama is already highly rated and ratings barely vary.
- Ratings come from one website and can be inflated when few people vote.
- Results show association, not cause and effect.
- No popularity column exists, so rating vs popularity could not be studied.
- Genres, actors and networks are multi-valued, so group counts overlap.

## 9. Future improvements
- Add a larger dataset that includes lower-rated dramas to avoid selection bias.
- Add viewership or social-media data to measure success beyond ratings.
- Use the synopsis and tags with NLP to find which story themes score well.
- Build a recommender system and publish the dashboard as a Streamlit app.